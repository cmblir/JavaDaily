package poly.ex2;

public class Pig extends Animal{
    @Override
    public void sound() {
        System.out.println("�ܲ�");
    }
}
