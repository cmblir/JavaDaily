package poly.ex.sender;

public interface Sender {
    public void sendMessage(String message);
}
