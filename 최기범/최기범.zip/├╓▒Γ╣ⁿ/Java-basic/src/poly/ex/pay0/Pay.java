package poly.ex.pay0;

public interface Pay {
    public boolean pay(int amount);
}
