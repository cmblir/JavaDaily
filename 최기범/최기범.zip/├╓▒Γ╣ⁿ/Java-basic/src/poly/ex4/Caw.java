package poly.ex4;

public class Caw extends AbstractAnimal {
    @Override
    public void sound() {
        System.out.println("����");
    }
    @Override public void move() {
        System.out.println("�� �̵�");
    }
}