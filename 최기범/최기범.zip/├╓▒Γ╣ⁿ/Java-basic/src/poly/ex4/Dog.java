package poly.ex4;

public class Dog extends AbstractAnimal {
    @Override
    public void sound() {
        System.out.println("�۸�");
    }
    @Override
    public void move() {
        System.out.println("�� �̵�");
    }
}
