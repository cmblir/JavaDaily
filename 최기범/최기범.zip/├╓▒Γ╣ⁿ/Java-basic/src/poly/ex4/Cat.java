package poly.ex4;

public class Cat extends AbstractAnimal{
    @Override
    public void sound() {
        System.out.println("�Ŀ�");
    }
    @Override
    public void move() {
        System.out.println("������ �̵�");
    }
}
