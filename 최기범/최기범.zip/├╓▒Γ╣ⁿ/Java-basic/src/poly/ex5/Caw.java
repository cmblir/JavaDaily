package poly.ex5;

public class Caw implements InterfaceAnimal{

    @Override
    public void sound() {
        System.out.println("����");
    }
    @Override
    public void move() {
        System.out.println("�� �̵�");
    }
}
