package poly.ex1;

public class Caw {
    public void sound() {
        System.out.println("����");
    }
}
