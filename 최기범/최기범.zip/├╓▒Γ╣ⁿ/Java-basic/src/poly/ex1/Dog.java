package poly.ex1;

public class Dog {
    public void sound() {
        System.out.println("�۸�");
    }
}
