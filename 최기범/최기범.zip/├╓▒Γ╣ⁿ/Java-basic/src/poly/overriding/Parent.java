package poly.overriding;

public class Parent {
    public String value = "parent";
    public void method() {
        System.out.println("Parent.method");
    }
}