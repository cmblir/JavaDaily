package poly.ex3;

public class Dog extends Animal {
    @Override
    public void sound() {
        System.out.println("�۸�");
    }
}
