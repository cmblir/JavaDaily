package poly.ex3;

public class Cat extends Animal{
    @Override
    public void sound() {
        System.out.println("�Ŀ�");
    }
}
