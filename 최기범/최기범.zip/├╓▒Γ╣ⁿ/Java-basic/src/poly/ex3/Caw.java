package poly.ex3;

public class Caw extends Animal{
    @Override
    public void sound() {
        System.out.println("����");
    }
}
