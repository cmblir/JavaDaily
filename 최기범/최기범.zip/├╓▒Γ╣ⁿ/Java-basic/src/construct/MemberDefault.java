package construct;

public class MemberDefault {
    String name;
    public MemberDefault() {

    }


}
