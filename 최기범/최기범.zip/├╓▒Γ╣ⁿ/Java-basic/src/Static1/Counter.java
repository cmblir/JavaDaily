package Static1;

public class Counter {
    public int count;

}
