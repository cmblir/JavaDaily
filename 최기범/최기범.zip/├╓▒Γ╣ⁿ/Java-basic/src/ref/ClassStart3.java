package ref;

public class ClassStart3 {
    public ClassStart3() {
    }

    public static void main(String[] args) {
        Student[] students = new Student[2];
        Student student1 = createStudent("�л�1", 15, 90);
        students[0] = student1;
        Student student2 = createStudent("�л�2", 16, 80);
        students[1] = student2;
        Student[] var4 = students;
        int var5 = students.length;

        for(int var6 = 0; var6 < var5; ++var6) {
            Student student = var4[var6];
            printStudent(student);
        }

    }

    static Student createStudent(String name, int age, int grade) {
        Student student = new Student();
        student.name = name;
        student.age = age;
        student.grade = grade;
        return student;
    }

    static void printStudent(Student student) {
        System.out.println("�̸� : " + student.name + " ���� : " + student.age + " ���� : " + student.grade);
    }

    static void initStudent(Student student, String name, int age, int grade) {
        student.name = name;
        student.age = age;
        student.grade = grade;
    }
}
