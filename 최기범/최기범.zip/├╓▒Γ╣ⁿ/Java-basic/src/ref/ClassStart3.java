package ref;

public class ClassStart3 {
    public static void main(String[] args) {
        Student[] students = new Student[2];

        Student student1 = createStudent("�л�1", 15, 90);
        students[0] = student1;

        Student student2 = createStudent("�л�2", 16, 80);
        students[1] = student2;

        for (Student student : students) {
            printStudent(student);
        }
    }

    static Student createStudent(String name, int age, int grade) {
        Student student = new Student();
        student.name = name;
        student.age = age;
        student.grade = grade;
        return student;
    }

    static void printStudent(Student student) {
        System.out.println("�̸� : " + student.name + " ���� : " + student.age
                + " ���� : " + student.grade);
    }

    static void initStudent(Student student, String name, int age, int grade) {
        student.name = name;
        student.age = age;
        student.grade = grade;
    }
}
