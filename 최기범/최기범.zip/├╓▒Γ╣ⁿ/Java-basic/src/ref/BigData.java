package ref;

public class BigData {
    Data data;
    int count;
}
