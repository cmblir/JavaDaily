package ref;

public class Student {
    String name;
    int age;
    int grade;

    public Student() {
    }
}
