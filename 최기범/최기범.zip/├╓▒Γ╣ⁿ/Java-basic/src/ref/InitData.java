package ref;

public class InitData {
    int value1;
    int value2;

}
