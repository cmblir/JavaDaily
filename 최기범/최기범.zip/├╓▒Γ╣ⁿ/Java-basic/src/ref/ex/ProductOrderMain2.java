package ref.ex;

public class ProductOrderMain2 {
    public static void main(String[] args) {
        ProductOrder[] orders = new ProductOrder[3];
        ProductOrder tofu = new ProductOrder("�κ�", 2000, 2);
        orders[0] = tofu;
        ProductOrder kimchi = new ProductOrder("��ġ", 5000, 1);
        orders[1] = kimchi;
        ProductOrder cola = new ProductOrder("�ݶ�", 1500, 2);
        orders[2] = cola;

        printOrders(orders);
        int totalAmount = getTotalAmount(orders);
        System.out.println("total amount = " + totalAmount);
    }
    static ProductOrder createOrder(String productName, int price, int quantity)
    {
        ProductOrder order = new ProductOrder();
        order.productName = productName;
        order.price = price;
        order.quantity = quantity;
        return order;
    }

    static void printOrders(ProductOrder[] orders) {
        for (ProductOrder order : orders) {
            System.out.println("��ǰ�� : " + order.productName + " ���� : " + order.price + " ���� : " + order.quantity);
        }
    }
    
    static int getTotalAmount(ProductOrder[] orders) {
        int totalAmount = 0;
        for (ProductOrder order : orders) {
            totalAmount += order.price * order.quantity;
        }
        return totalAmount;
    }
}
