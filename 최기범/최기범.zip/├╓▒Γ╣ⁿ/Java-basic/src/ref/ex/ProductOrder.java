package ref.ex;

public class ProductOrder {
    String productName;
    int price;
    int quantity;
    public ProductOrder(){ }
    public ProductOrder(String productName, int price, int quantity) {
        this.productName = productName;
        this.price = price;
        this.quantity = quantity;
    }

    public void printInfo() {
        System.out.println("��ǰ�� : " + this.productName + " ,���� : " + this.price + " ,���� : " + this.quantity);
    }
}
