package ref.ex;

import java.util.Scanner;

public class ProductOrderMain3 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.print("��ǰ�� ������ �Է��ϼ��� : ");
        int n = scn.nextInt();
        scn.nextLine();
        ProductOrder[] orders = new ProductOrder[n];
        for (int i = 0; i < orders.length; i++) {
            System.out.println((i+1) + "��° ���� ���� �Է�");
            System.out.print("��ǰ�� : ");
            String productName = scn.nextLine();
            System.out.print("��ǰ ���� : ");
            int price = scn.nextInt();
            System.out.print("��ǰ ���� : ");
            int quantity = scn.nextInt();
            scn.nextLine();
            orders[i] =new ProductOrder(productName, price, quantity);
        }
        printOrders(orders);
        int totalAmount = getTotalAmount(orders);
        System.out.println("�� �ݾ� = " + totalAmount);
    }
    static ProductOrder createOrder(String productName, int price, int quantity)
    {
        ProductOrder order = new ProductOrder();
        order.productName = productName;
        order.price = price;
        order.quantity = quantity;
        return order;
    }

    static void printOrders(ProductOrder[] orders) {
        for (ProductOrder order : orders) {
            System.out.println("��ǰ�� : " + order.productName + " ���� : " + order.price + " ���� : " + order.quantity);
        }
    }
    
    static int getTotalAmount(ProductOrder[] orders) {
        int totalAmount = 0;
        for (ProductOrder order : orders) {
            totalAmount += order.price * order.quantity;
        }
        return totalAmount;
    }
}
