package ref;

public class NullPointException {
    public static void main(String[] args) {
        Data data = null;
        data.value = 10;
        System.out.println("data : " + data.value);
    }
}
