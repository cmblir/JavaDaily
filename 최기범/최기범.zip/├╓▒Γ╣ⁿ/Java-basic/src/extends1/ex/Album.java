package extends1.ex;

public class Album extends Item{
    private String artist;
    public Album(String name, int price, String artist) {
        super(name, price);
        this.artist = artist;
    }

    @Override
    public void print(){
        System.out.println("�̸� : "  + name + ", ���� : " + price);
        System.out.println(" - ��Ƽ��Ʈ : " + artist);
    }
}
