package extends1.ex;

public class Movie extends Item{
    private String director;
    private String author;
    public Movie(String name, int price, String director, String author) {
        super(name, price);
        this.director = director;
        this.author = author;
    }
    @Override
    public void print(){
        System.out.println("�̸� : "  + name + ", ���� : " + price);
        System.out.println(" - ���� : " + director + " , ��� : " + author);
    }
}
