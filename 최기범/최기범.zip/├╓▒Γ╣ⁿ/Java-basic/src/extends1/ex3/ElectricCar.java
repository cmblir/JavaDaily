package extends1.ex3;

public class ElectricCar extends Car {
    public void charge() {
        System.out.println("�����մϴ�.");
    }
}
