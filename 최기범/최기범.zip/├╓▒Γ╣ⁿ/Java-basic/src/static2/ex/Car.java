package static2.ex;

public class Car {
    static int totalCarNum;
    private String name;

    public Car(String name) {
        this.name = name;
        totalCarNum++;
    }

    public static void showTotalCars() {
        System.out.println("������ ���� �� : " + totalCarNum);
    }
}
