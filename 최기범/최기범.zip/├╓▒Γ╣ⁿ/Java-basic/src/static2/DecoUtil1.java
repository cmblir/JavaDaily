package static2;

public class DecoUtil1 {
    public String deco(String str) {
        String result = "* " + str + " *";
        return result;
    }
}
