package oop1;

public class ValueObject {
    int value;

    void add() {
        value++;
        System.out.println("���� ���� value = " + value);
    }
}