package class1.ex;

public class ProductOrderMain {
    public static void main(String[] args) {
        ProductOrder[] orders = new ProductOrder[3];

        ProductOrder tofu = new ProductOrder("�κ�", 2000,2);
        orders[0] = tofu;

        ProductOrder kimchi = new ProductOrder("��ġ", 5000,1);
        orders[1] = kimchi;

        ProductOrder cola = new ProductOrder("�ݶ�", 1500,2);
        orders[2] = cola;

        int totalAmount = 0;
        for (ProductOrder order : orders) {
            order.printInfo();
            totalAmount = order.price * order.quantity;

        }

        System.out.println("�� ���� �ݾ� : " + totalAmount);



    }
}
