package access.b;

import access.a.AccessData;

public class AccessOuterMain {
    public static void main(String[] args) {
        AccessData data = new AccessData();
        data.publicField = 1;
        data.publicMethod();

        // �ٸ� ��Ű�� �Ҽ�
        // data.defaultField = 2;
        // data.defaultMethod();

        // data.privateField = 2;
        // data.privateMethod();

        data.innerAccess();
    }
}
