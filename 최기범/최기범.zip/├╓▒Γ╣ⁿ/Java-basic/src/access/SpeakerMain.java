package access;

public class SpeakerMain {
    public static void main(String[] args) {
        Speaker speaker = new Speaker(10);
        speaker.showVolume();

        speaker.volumeUp();
        speaker.showVolume();

        speaker.volumeUp();
        speaker.showVolume();

    }
}

