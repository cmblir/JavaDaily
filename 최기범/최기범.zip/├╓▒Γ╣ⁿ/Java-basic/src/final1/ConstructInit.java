package final1;

public class ConstructInit {
    final int value;

    public ConstructInit(int value) {
        this.value = value;
    }
}
