package variable;

public class Var1 {

    public static void main(String[] args) {
        System.out.println(20); //변경 10 -> 20
        System.out.println(20); //변경 10 -> 20
        System.out.println(20); //변경 10 -> 20
    }
}
