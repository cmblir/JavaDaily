package variable;

public class Var4 {

    public static void main(String[] args) {
        int a;
        int b;

        int c,d;
    }
}
