package variable.ex;

public class VarEx1Question {

    public static void main(String[] args) {
        System.out.println(4 + 3);
        System.out.println(4 - 3);
        System.out.println(4 * 3);
    }
}
