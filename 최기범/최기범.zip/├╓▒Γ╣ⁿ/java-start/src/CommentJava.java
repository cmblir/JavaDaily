public class CommentJava {

    public static void main(String[] args) {
        System.out.println("hello java1"); //hello java1을 출력합니다.
        //System.out.println("hello java2");

        /*
        System.out.println("hello java3");
        System.out.println("hello java4");
        */
    }
}
