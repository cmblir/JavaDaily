package src.method;

public class Method1 {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;

        System.out.println(sum(a,b));
    }

    static int sum(int a, int b) {
        return a + b;
    }
}
