package src.test;

public class Operator1 {
    public static void main(String[] args) {
        int a = 10;
        int b = 2;

        int sum = a + b;
        System.out.println("a + " + "b = " + sum);

        int multiple = a * b;
        System.out.println("a * " + "b = " + multiple);

        int divide = a / b;
        System.out.println("a / b = " + divide);

        int mod = a % b;
        System.out.println("a % b = " + mod);




    }
}
