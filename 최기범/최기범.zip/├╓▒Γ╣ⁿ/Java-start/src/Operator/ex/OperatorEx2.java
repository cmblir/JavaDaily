package src.Operator.ex;

public class OperatorEx2 {
    public static void main(String[] args) {
        double val1 = 1.5;
        double val2 = 2.5;
        double val3 = 3.5;

        double sumVal = val1 + val2 + val3;
        double avgVal = (sumVal) / 3;

        System.out.println(sumVal);
        System.out.println(avgVal);
    }
}
