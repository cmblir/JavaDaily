package src.Operator.ex;

public class OperatorEx3 {
    public static void main(String[] args) {
        int score = 80;
        boolean result = score >= 60 && score <= 100;
        System.out.println(result);
    }
}
