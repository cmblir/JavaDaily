package src.Operator.ex;

public class OperatorEx1 {
    public static void main(String[] args) {
        int num1 = 10;
        int num2 = 20;
        int num3 = 30;

        int sumVal = num1 + num2 + num3;
        int avgVal = (sumVal) / 3;

        System.out.println(sumVal);
        System.out.println(avgVal);
    }
}
