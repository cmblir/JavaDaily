package operator;
public class Operator4 {
    public static void main(String[] args) {
        int sum3 = 2 * 2 + 3 * 3; //(2 * 2) + (3 * 3)
        int sum4 = (2 * 2) + (3 * 3); //sum3과 같다.
        System.out.println("sum3 = " + sum3); //sum3 = 13 System.out.println("sum4 = " + sum4); //sum4 = 13
    }
}