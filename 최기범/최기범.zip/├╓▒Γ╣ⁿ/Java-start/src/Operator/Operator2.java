package src.Operator;

public class Operator2 {
    public static void main(String[] args) {
        String a = "hello";
        String b = "world";

        String result = a + b;
        System.out.println(result);

    }
}
